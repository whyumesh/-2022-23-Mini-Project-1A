
package connection;

import com.sun.jdi.connect.spi.Connection;


public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;
    public static DatabaseConnection getInstance(){
        if(instance==null){
            instance = new DatabaseConnection();
            }
        return instance;
    }
    private String port;
    public DatabaseConnection(){
        
    }
    public void connectToDatabase() throws SQLException, ClassNotFoundException, java.sql.SQLException {
        String server="localhost";
        String host="3306";
        String database = "seds";
        String user="root";
        String password="123456";
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection = (Connection) java.sql.DriverManager.getConnection("jdbc:mysql://" + server +":" + port +"/"+database+"?verifyServerCertificate=true&useSSL=false",user, password);
    }

    /**
     * @return the connection
     */
    public Connection getConnection() {
        return connection;
    }
    
    
}
